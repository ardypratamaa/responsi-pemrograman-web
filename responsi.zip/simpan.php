<?php  
$nama = $_POST['nama'];
$email = $_POST['email'];
$notelp = $_POST['notelp'];
$sewa = $_POST['sewa'];
$balik = $_POST['balik'];
$alamat = $_POST['alamat'];
$pilih = $_POST['pilih'];
$bayar = $_POST['bayar'];

$fp = fopen("output.txt", "a+");
fputs($fp,"DATA REGISTRASI PENYEWAAN MOBIL\n");
fputs($fp,"===============================\n");
fputs($fp,"Nama         : $nama\n");
fputs($fp,"Email        : $email\n");
fputs($fp,"No Telp      : $notelp\n");
fputs($fp,"Tgl Sewa     : $sewa\n");
fputs($fp,"Tgl Kembali  : $balik\n");
fputs($fp,"Alamat       : $alamat\n");
fputs($fp,"Jenis Mobil  : $pilih\n");
fputs($fp,"Pembayaran   : $bayar\n");
fputs($fp,"===============================\n");
fclose($fp);

echo "Output terkirim<br>";
echo '<a href="index.html">Halaman Awal</a></br></br>';
 ?>  